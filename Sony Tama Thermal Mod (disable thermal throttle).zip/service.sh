#!/system/bin/sh
# Do NOT assume where your module will be located.
# ALWAYS use $MODDIR if you need to know where this script
# and module is placed.
# This will make sure your module will still work
# if Magisk change its mount point in the future
MODDIR=${0%/*}

# This script will be executed in late_start service mode
sleep 10
stop perfd
echo '100' > /proc/sys/vm/swappiness
echo '1' > /sys/module/lowmemorykiller/parameters/enable_adaptive_lmk
echo '100' > /proc/sys/vm/vfs_cache_pressure
echo '8000' > /proc/sys/vm/min_free_kbytes
echo '0' > /proc/sys/vm/oom_kill_allocating_task
echo '5' > /proc/sys/vm/dirty_ratio
echo '20' > /proc/sys/vm/dirty_background_ratio
chmod 666 /sys/module/lowmemorykiller/parameters/minfree
chown root /sys/module/lowmemorykiller/parameters/minfree
echo '21816,29088,36360,43632,50904,65448' > /sys/module/lowmemorykiller/parameters/minfree
echo '0,1,2,4,7,15' > /sys/module/lowmemorykiller/parameters/adj
echo '0' > /sys/module/lowmemorykiller/parameters/debug_level
echo '48' > /sys/module/lowmemorykiller/parameters/cost
echo '0' > /sys/class/kgsl/kgsl-3d0/throttling
rm /data/system/perfd/default_values
start perfd
# Set Activity Manager's max. cached app number -> 160 (instead of the default 32 (or even lower 24):
settings put global activity_manager_constants max_cached_processes=160
sleep 1
done